## app.R ##
library(shinydashboard)
library(shinythemes)
library(shinyLP)
library(stringi)
library(ngramrr)
library(ngram)
library(shinyjs)
library(TransP )
library(lpSolve )
Minimize<-function(s){
  reslt <- read.csv(s$datapath, header=FALSE, sep=";")
  
  f.obj <-c(reslt[1,2:4])
    f.con <- matrix (c(1,2,3,3,2,2), nrow=2, byrow=TRUE)
    f.dir <- c(as.character( reslt[4,1]),as.character( reslt[5,1]))
    f.rhs <- c(reslt[4,2], reslt[5,2])

  res=lp (tolower(as.character(reslt[1,1])), f.obj, f.con, f.dir, f.rhs,compute.sens=TRUE)
  pr=lp (tolower(as.character(reslt[1,1])), f.obj, f.con, f.dir, f.rhs,compute.sens=TRUE)$solution
  duals=lp (tolower(as.character(reslt[1,1])), f.obj, f.con, f.dir, f.rhs,compute.sens=TRUE)$duals
  
  return(list(primal=pr,duals=duals,obj1=res))
  
  
}


Transport<-function (s) 
{
  Table_Transport=read.csv(s$datapath,sep=";")
  Tab_Transport=data.frame(Table_Transport)
  
  
  
  x=rownames(Tab_Transport)=Tab_Transport[1:nrow(Tab_Transport),1]
  d=(data.frame(mincost(Tab_Transport[2:ncol(Tab_Transport)])))
  colnames(d)=colnames((Tab_Transport)[2:6])
  c=mincost(Tab_Transport[2:ncol(Tab_Transport)])
  near=nwc (Tab_Transport[2:ncol(Tab_Transport)])
  return(list(TT=Tab_Transport[2:ncol(Tab_Transport)],Mincostt=d,c=c,Near=near))
  
}

ui <- dashboardPage(
  skin = "purple",
  title = "Logistique ESCT/IHEC",
  dashboardHeader(title = span(tagList(img(src="d.png",width="45"), "logistique Esct/IHEC"))  ,    titleWidth = 350
  ),
  
  
  
  
  
  
  
  dashboardSidebar(
    sidebarMenu(
      menuItem("Probleme De Transport", tabName = "M1", icon = icon("adn","fa-20x")),
      menuItem("Resoultion Lineaire ", tabName = "M2", icon = icon("table"))
      
      #menuItem( "Widgets",,icon = icon("th")),
      
      
      
      
    )
  )
  ,
  dashboardBody(  useShinyjs(),
                  tags$head(
                    tags$link(rel = "stylesheet", type = "text/css", href = "bio.css")
                  ),
                  tags$head(  tags$script(
                    HTML("
                         Shiny.addCustomMessageHandler ('hide',function (selector) {
                         $(selector).parent().slideUp();
                         });"
  )
                    )
                  ),
  tags$head(tags$link(rel = "shortcut icon", href = "https://icon-icons.com/icons2/495/PNG/512/dna_icon-icons.com_48637.png")),
  
  # Boxes need to be put in a row (or column)

    
  
    
  tabItems(
    tabItem(tabName = "M1",
            fluidRow(
              
              
              box(fileInput("file","import Tableau de Transport .csv"),height =100,width=6)
              ,verbatimTextOutput("text5")
            ),
            box(title = " Tableau De Transport",status="primary", solidHeader = TRUE,
                div(DT::dataTableOutput("view" ), style = "font-size:60%")
                
                
                
            ),
            
            box(
              title = " Resultat: La Methode du coin Nord-Ouest",status="primary", solidHeader = TRUE,
              
              verbatimTextOutput("text2")
              
              
            ),
            box(
              title = " Resultat:La Methode des Couts Minimums  ",status="primary", solidHeader = TRUE,
            
              verbatimTextOutput("text")
              
              
            )
    ),
  tabItem(tabName = "M2",  fluidRow(
    
    
    box(fileInput("file2","import file"),height =100)
    
  ),box(
    title = " Resultat:",status="primary", solidHeader = TRUE,
    
    verbatimTextOutput("text3"),
    verbatimTextOutput("primal"),
    verbatimTextOutput("text4")

    
    
  )
  )
    
  )
                  )
                  )



server <- function(input, output) {
  
  
  set.seed(122)
  histdata <- rnorm(500)

  output$text2 <- renderPrint  ({
    s <- input$file
    if(is.null(s)){return("----");}
    m1=Transport(s)$Near
    
    print(m1)
  })
  output$text3 <- renderPrint  ({
    s <- input$file2
    if(is.null(s)){return("----");}
 
    print("Fonction Objectif = ")
    Minimize(s)$obj1

  
  })
  output$text4 <- renderPrint  ({
    s <- input$file2
    if(is.null(s)){return("M1 IDIAG");}

    print("Dual")
    Minimize(s)$duals
    
    
  })
  output$primal <- renderPrint  ({
    s <- input$file2
    if(is.null(s)){return("M1 IDIAG");}
    
    print("solution optimale")
    Minimize(s)$primal
    
    
  })
  
  
  output$text <- renderPrint  ({
    s <- input$file
    if(is.null(s)){return("");}
    m1=Transport(s)$c
    
    print(m1)
  })
  
  output$text5 <- renderPrint  ({
    s <- input$file
    if(is.null(s)){return("Realise par : Arfaoui Youssef Mounir Secrafi");}

   
  })
  output$plot1 <- renderPlot({
    data <- histdata[seq_len(input$slider)]
    hist(data)
  })
  output$plot <- renderPlot({
    
    # Add a little noise to the cars data
    s <- input$file
    if(is.null(s)){return("Realise par : Arfaoui Youssef Mounir Secrafi");}
    x=Minimize(s)$primal
    plot(x, type = "s", main = "Courbe Resultat Optimal(xi)")
    points(x, cex = .5, col = "dark red")
  })
  
  getData = output$view <- DT::renderDT({
    s <- input$file
    if(is.null(s)){return(NULL);}
    m1=Transport(s)$TT;
    
    print(m1)
    
    
    m1
  },options = list(scrollX = TRUE))
  getData = output$view2 <- DT::renderDT({
    s <- input$file
    if(is.null(s)){return(NULL);}
    
    
  },options = list(scrollX = TRUE))

  
}




    
shinyApp(ui, server)
